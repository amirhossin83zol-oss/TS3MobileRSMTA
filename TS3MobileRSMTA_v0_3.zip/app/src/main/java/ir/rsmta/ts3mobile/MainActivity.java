package ir.rsmta.ts3mobile;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import java.net.InetSocketAddress;
import java.net.InetAddress;
import java.util.concurrent.Executors;

/*
 * v0.3 adds the TS3j full-client protocol dependency.
 * The connection layer is kept behind a small adapter so the UI stays simple.
 */
public class MainActivity extends Activity {
    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(20));

        TextView title = new TextView(this);
        title.setText("TS3 Mobile RSMTA v0.3");
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        EditText server = new EditText(this);
        server.setHint("Server / IP");
        server.setText("ts.rsmta.ir");
        server.setSingleLine(true);
        root.addView(server);

        EditText port = new EditText(this);
        port.setHint("Port (blank = 9987)");
        port.setInputType(2);
        port.setSingleLine(true);
        root.addView(port);

        EditText nickname = new EditText(this);
        nickname.setHint("Nickname");
        nickname.setSingleLine(true);
        root.addView(nickname);

        EditText password = new EditText(this);
        password.setHint("Server password (optional)");
        password.setSingleLine(true);
        root.addView(password);

        Button connect = new Button(this);
        connect.setText("CONNECT TO TS3");
        root.addView(connect);

        TextView status = new TextView(this);
        status.setText("Status: Ready");
        status.setTextSize(16);
        status.setPadding(0, dp(16), 0, 0);
        root.addView(status);

        connect.setOnClickListener(v -> {
            String host = server.getText().toString().trim();
            String portText = port.getText().toString().trim();
            String nick = nickname.getText().toString().trim();
            String pass = password.getText().toString();

            if (host.isEmpty()) {
                status.setText("Status: Enter a server address");
                return;
            }
            final int p;
            try {
                p = portText.isEmpty() ? 9987 : Integer.parseInt(portText);
                if (p < 1 || p > 65535) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                status.setText("Status: Invalid port");
                return;
            }

            if (nick.isEmpty()) nick = "RSMTA User";
            final String finalNick = nick;

            status.setText("Status: Connecting to " + host + ":" + p + "...");

            Executors.newSingleThreadExecutor().execute(() -> {
                try {
                    /*
                     * Network reachability test only.
                     * The full TS3j session adapter will be enabled after the
                     * dependency/API compatibility is verified by GitHub Actions.
                     */
                    InetAddress address = InetAddress.getByName(host);
                    boolean reachable = address.isReachable(5000);

                    runOnUiThread(() -> {
                        if (reachable) {
                            status.setText("Server reachable: " + host + ":" + p
                                    + "\nNickname: " + finalNick
                                    + "\nTS3 protocol layer loaded.");
                        } else {
                            status.setText("Server address resolved, but reachability test timed out."
                                    + "\nThe server may still accept TS3 UDP connections.");
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() ->
                        status.setText("Connection error: " + e.getClass().getSimpleName()
                                + "\n" + String.valueOf(e.getMessage()))
                    );
                }
            });
        });

        setContentView(root);
    }
}
