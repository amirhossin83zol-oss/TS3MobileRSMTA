# TS3MobileRSMTA v0.3

This build adds the open-source TS3j full-client protocol library (Apache-2.0) as a Gradle dependency.

Server defaults:
- ts.rsmta.ir
- 5.57.32.20
- voice port 9987

The UI performs a network reachability check. The next iteration will wire the TS3j LocalTeamspeakClientSocket session to channel/user events. Voice/audio will be added after the protocol connection is verified.

Source:
Manevolent/ts3j 1.0.2
