package ir.rsmta.ts3mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                TS3MobileApp()
            }
        }
    }
}

data class Channel(
    val name: String,
    val users: List<String>
)

class MainViewModel : ViewModel() {
    var connected by mutableStateOf(false)
        private set

    var server by mutableStateOf("ts.rsmta.ir")
    var port by mutableStateOf("9987")
    var nickname by mutableStateOf("")
    var password by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
        private set

    var micMuted by mutableStateOf(false)
        private set
    var deafened by mutableStateOf(false)
        private set
    var pushToTalk by mutableStateOf(false)
        private set

    // UI-only sample data for v0.1. Real TS3 protocol/voice comes in the next layer.
    val channels = listOf(
        Channel("Lobby", listOf("User1", "User2")),
        Channel("Gaming", listOf("User3", "User4")),
        Channel("AFK", emptyList())
    )

    fun connect() {
        if (server.isBlank()) {
            error = "آدرس سرور را وارد کن."
            return
        }
        if (port.toIntOrNull() == null) {
            error = "پورت نامعتبر است."
            return
        }
        if (nickname.isBlank()) {
            error = "یک Nickname وارد کن."
            return
        }

        error = null
        // v0.1: connection state only. Network implementation is intentionally separate.
        connected = true
    }

    fun disconnect() {
        connected = false
        pushToTalk = false
    }

    fun toggleMic() {
        micMuted = !micMuted
    }

    fun toggleDeafen() {
        deafened = !deafened
    }

    fun setPtt(value: Boolean) {
        if (!micMuted && !deafened) pushToTalk = value
    }
}

@Composable
fun TS3MobileApp(vm: MainViewModel = viewModel()) {
    if (vm.connected) {
        ServerScreen(vm)
    } else {
        ConnectScreen(vm)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectScreen(vm: MainViewModel) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("TS3 Mobile RSMTA") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Text("اتصال به TeamSpeak 3", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(18.dp))

            OutlinedTextField(
                value = vm.server,
                onValueChange = { vm.server = it },
                label = { Text("Server Address") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = vm.port,
                onValueChange = { vm.port = it.filter(Char::isDigit) },
                label = { Text("Port") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = vm.nickname,
                onValueChange = { vm.nickname = it },
                label = { Text("Nickname") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = vm.password,
                onValueChange = { vm.password = it },
                label = { Text("Server Password (optional)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(18.dp))

            vm.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(10.dp))
            }

            Button(
                onClick = vm::connect,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("CONNECT")
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "پیش‌فرض پروژه: ts.rsmta.ir:9987",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServerScreen(vm: MainViewModel) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("RSMTA") },
                actions = {
                    OutlinedButton(onClick = vm::disconnect) {
                        Text("Disconnect")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Text(
                "Connected to ${vm.server}:${vm.port}",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            HorizontalDivider()
            Spacer(Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.channels) { channel ->
                    ChannelCard(channel)
                }
            }

            HorizontalDivider()
            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                OutlinedButton(onClick = vm::toggleMic) {
                    Text(if (vm.micMuted) "🔇 Mic ON" else "🎤 Mic Mute")
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = vm::toggleDeafen) {
                    Text(if (vm.deafened) "🔈 Deafen OFF" else "🔊 Deafen")
                }
            }

            Spacer(Modifier.height(10.dp))

            Button(
                onClick = { vm.setPtt(!vm.pushToTalk) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
            ) {
                Text(if (vm.pushToTalk) "🎙 TALKING..." else "🎙 PUSH TO TALK")
            }

            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun ChannelCard(channel: Channel) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(channel.name, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))

            if (channel.users.isEmpty()) {
                Text("خالی", style = MaterialTheme.typography.bodySmall)
            } else {
                channel.users.forEach {
                    Text("👤 $it", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}