# TS3 Mobile RSMTA — v0.1

این نسخه «اسکلت رابط کاربری» است، نه کلاینت واقعی TeamSpeak 3.

## امکانات v0.1
- صفحه اتصال
- Server Address پیش‌فرض: ts.rsmta.ir
- Port پیش‌فرض: 9987
- Nickname
- Server Password
- صفحه سرور
- نمایش نمونه Channel/User
- دکمه‌های Mic / Deafen / Push-to-Talk
- ساختار ViewModel برای جداکردن UI از منطق اتصال

## نکته مهم
در v0.1 دکمه CONNECT فقط وضعیت رابط کاربری را تغییر می‌دهد و هنوز به پروتکل واقعی TS3 وصل نمی‌شود.
لایه بعدی باید پروتکل/Voice سازگار با TeamSpeak 3 را جداگانه پیاده‌سازی و از نظر مجوزهای استفاده بررسی کند.

## تکنولوژی
- Kotlin
- Jetpack Compose
- Material 3
- AndroidX ViewModel
- minSdk 26
- target/compile SDK 36

این انتخاب‌ها با مستندات فعلی Android برای پروژه‌های Compose هم‌راستا هستند. برای پروژه جدید، Android Developers استفاده از Empty Activity + Compose را توصیه می‌کند.